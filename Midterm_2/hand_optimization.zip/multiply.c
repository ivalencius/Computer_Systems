// Author: Ilan Valencius
// Email: valencig@bc.edu

// Takes numbers x, y and multiplies them
long multiply(long x, long y) {
    return x * y;
}